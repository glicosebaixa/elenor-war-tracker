import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || Deno.env.get("SB_SECRET_KEY");
if (!SUPABASE_KEY) throw new Error("Supabase service key is missing");

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
const GUILD_URL = "https://www.wotserver.com/?view=guilds&action=show&guild=166";
const WOT = "https://www.wotserver.com";
const IDLE_MS = 180_000;
const LOCK_SECONDS = 20;

const headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store",
};

function clean(s: string) { return (s || "").replace(/\s+/g, " ").trim(); }
function textFromHtml(html: string) {
  return clean(html.replace(/<script[\s\S]*?<\/script>/gi," ").replace(/<style[\s\S]*?<\/style>/gi," ").replace(/<[^>]+>/g," ")
    .replace(/&nbsp;/gi," ").replace(/&amp;/gi,"&").replace(/&#39;/gi,"'").replace(/&quot;/gi,'"'));
}

async function get(url: string) {
  const u = url + (url.includes("?") ? "&" : "?") + "_wt=" + Date.now() + Math.random().toString(36).slice(2);
  const res = await fetch(u, { headers: {
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140 Safari/537.36",
    "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Cache-Control":"no-cache, no-store, max-age=0", "Pragma":"no-cache"
  }});
  if (!res.ok) throw new Error(`WOTServer HTTP ${res.status}`);
  return await res.text();
}

type Member = {name:string; level:number; online:boolean; url:string};
function parseGuild(html:string): Member[] {
  const out:Member[]=[];
  for (const row of html.match(/<tr[\s\S]*?<\/tr>/gi) || []) {
    const a=row.match(/<a[^>]+href=["']([^"']*view=characters[^"']*)["'][^>]*>([\s\S]*?)<\/a>/i);
    if(!a) continue;
    const name=clean(a[2].replace(/<[^>]+>/g,""));
    const txt=textFromHtml(row);
    const pos=txt.indexOf(name);
    if(!name || pos<0) continue;
    const levelMatch=txt.slice(pos+name.length).match(/\b(\d{1,5})\b/);
    if(!levelMatch) continue;
    out.push({name, level:Number(levelMatch[1]), online:/\bOnline\b/i.test(txt), url:new URL(a[1],WOT).href});
  }
  return [...new Map(out.map(x=>[x.name.toLowerCase(),x])).values()];
}
function parseCharacter(html:string) {
  const txt=textFromHtml(html);
  const lm=txt.match(/\bLevel\s*\|\s*(\d{1,5})\b/i);
  const xm=txt.match(/Exp:\s*([\d.,\s]+)\s+e\s+precisa/i);
  return {level:lm?Number(lm[1]):null, xp:xm?Number(xm[1].replace(/[^0-9]/g,"")):null};
}
function xpRate(oldXp:number|null, oldChecked:string|null, newXp:number, nowMs:number) {
  if(oldXp==null || !oldChecked || newXp<=oldXp) return null;
  const dt=(nowMs-Date.parse(oldChecked))/3600000;
  return dt>0 ? Math.round((newXp-oldXp)/dt) : null;
}

Deno.serve(async (req)=>{
  if(req.method==="OPTIONS") return new Response("ok",{headers});
  const started=Date.now();
  try {
    const {data:claimed,error:lockErr}=await supabase.rpc("try_elenor_collector_lock",{p_seconds:LOCK_SECONDS});
    if(lockErr) throw lockErr;
    if(!claimed) return new Response(JSON.stringify({ok:true,skipped:true,reason:"collector_busy"}),{headers});

    const guild=await get(GUILD_URL);
    const members=parseGuild(guild);
    if(!members.length) throw new Error("Nenhum membro encontrado na guilda Soul Tatics");

    const {data:oldRows,error:readErr}=await supabase.from("players").select("id,name,level,status,xp,xp_per_hour,xp_checked_at,last_xp_gain_at").eq("group","soul");
    if(readErr) throw readErr;
    const oldMap=new Map((oldRows||[]).map((p:any)=>[p.name.toLowerCase(),p]));

    const online=members.filter(m=>m.online);
    const characterResults=await Promise.all(online.map(async m=>{
      try { return {m,c:parseCharacter(await get(m.url)),error:null}; }
      catch(e) { return {m,c:{level:null,xp:null},error:e instanceof Error?e.message:String(e)}; }
    }));
    const chars=new Map(characterResults.map(x=>[x.m.name.toLowerCase(),x]));

    const now=new Date(); const nowIso=now.toISOString(); const nowMs=now.getTime();
    const payloads:any[]=[]; const history:any[]=[]; let gains=0, errors=0;
    for(const m of members){
      const old:any=oldMap.get(m.name.toLowerCase());
      const ch:any=chars.get(m.name.toLowerCase());
      let xp=old?.xp ?? null;
      let level=m.level;
      let lastGain=old?.last_xp_gain_at ?? null;
      let perHour=old?.xp_per_hour ?? null;
      let lastError=null;
      if(m.online && ch){
        level=ch.c.level ?? m.level;
        if(ch.c.xp!=null){
          xp=ch.c.xp;
          if(old?.xp!=null && ch.c.xp>old.xp){
            const r=xpRate(old.xp,old.xp_checked_at,ch.c.xp,nowMs);
            perHour=r ?? perHour;
            lastGain=nowIso; gains++;
            history.push({player_id:old?.id ?? null,player_name:m.name,xp:ch.c.xp,level,recorded_at:nowIso});
          }
        } else lastError=ch.error;
      }
      const status=!m.online ? "offline" : (lastGain && nowMs-Date.parse(lastGain)<IDLE_MS ? "online":"pz");
      payloads.push({id:old?.id ?? undefined,name:m.name,level,group:"soul",status,last_seen:nowIso,xp,xp_per_hour:perHour,last_xp_gain_at:lastGain,xp_checked_at:nowIso,source:"wotserver",source_url:m.url,last_error:lastError});
      if(lastError) errors++;
    }

    const {data:saved,error:saveErr}=await supabase.from("players").upsert(payloads,{onConflict:"name"}).select("id,name");
    if(saveErr) throw saveErr;
    const idByName=new Map((saved||[]).map((p:any)=>[p.name.toLowerCase(),p.id]));
    const historyRows=history.map(h=>({...h,player_id:h.player_id || idByName.get(h.player_name.toLowerCase())})).filter(h=>h.player_id);
    if(historyRows.length){ const {error:e}=await supabase.from("player_xp_history").insert(historyRows); if(e) console.error("history",e); }

    await supabase.rpc("finish_elenor_collector_lock");
    return new Response(JSON.stringify({ok:true,guild:"Soul Tatics",members:members.length,online:online.length,processed:payloads.length,xp_gains:gains,errors,elapsed_ms:Date.now()-started,timestamp:nowIso}),{headers});
  } catch(e) {
    try{await supabase.rpc("finish_elenor_collector_lock");}catch{}
    return new Response(JSON.stringify({ok:false,error:e instanceof Error?e.message:String(e)}),{status:500,headers});
  }
});
